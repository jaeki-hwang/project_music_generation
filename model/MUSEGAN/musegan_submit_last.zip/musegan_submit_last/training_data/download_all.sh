#!/bin/bash
sh download.sh lastfm_alternative_5b_phrase.npy
sh download.sh lastfm_alternative_8b_phrase.npy
